//: Playground - noun: a place where people can play

import UIKit
print ("Topic about Collection Types like Arrays and Dictionaries")
//Welcome to the Show, will learn a lot here at XiApps
/*You can only read this because it's a comment, thanks for dropping by XD
 now back to regular programming */

var name = "Francis"
var purpose = "to teach and guide"

print ("Welcome to Collection Types, my name is \(name) and I'm here to \(purpose) you")
//nice XD

print("Let'start Dictionaries")








